const loginForm = document.getElementById('login-form')
const alert = document.getElementById('alert')

loginForm.addEventListener('submit', async event => {
  event.preventDefault()

  const email = event.target[0].value
  const password = event.target[1].value

  const response = await fetch('http://localhost:4008/api/users/authenticate', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ email, password }),
  })

  const data = await response.json()

  if (!data.token) {
    alert.innerText = `Error: ${data.message || 'unknown'}`
    alert.style.display = 'block'
  } else {
    location.replace(`http://localhost:4101/pages/login/?token=${data.token}`)
  }
})
